import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class RegistrationForm extends JDialog {
    private JTextField tfName;
    private JTextField tfEmail;
    private JTextField tfAge;
    private JPasswordField pfPassword;
    private JPasswordField pfConfirmPassword;
    private JButton btnRegister;
    private JButton btnCancel;
    private JPanel registerPanel;
    private JLabel lbName;
    private JLabel lbEmail;
    private JLabel lbPassword;
    private JLabel lbConfirmPassword;
    private JLabel lbAge;

    public RegistrationForm(JFrame parent) {
        super(parent);
        setTitle("Create a new account");
        setContentPane(registerPanel);
        setMinimumSize(new Dimension(500, 500));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    private void registerUser() {
        String name = tfName.getText();
        String email = tfEmail.getText();
        String age = tfAge.getText();
        String password = String.valueOf(pfPassword.getPassword());
        String confirmPassword = String.valueOf(pfConfirmPassword.getPassword());

        if (name.isEmpty() || email.isEmpty() || age.isEmpty()  || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter all fields",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this,
                    "Confirm Password does not match",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        try{
            Integer.valueOf(age);}
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this,
                    "Please enter a real age",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (Integer.valueOf(age)<0 ||  Integer.valueOf(age)>150) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a real age",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }


        if(uniquename(name)==0){
            JOptionPane.showMessageDialog(this,
                    "The username is already taken",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
        return;}
        int randomNum = ThreadLocalRandom.current().nextInt(1000, 10000);
        SendEmail sendemail = new SendEmail(name,"Welcome and thank you for making an account on Gstore",tfEmail.getText(),0,randomNum);
        if(sendemail.ok==1) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid email",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(verifyCode(randomNum)==0)
            return;
        connectToDatabase(name);
        connectToDatabase1(name);

        user = addUserToDatabase(name, email, age, password);
        if (user != null) {
            dispose();
        }
        else {
            JOptionPane.showMessageDialog(this,
                    "Failed to register new user",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
        }


    }

    public User user;

    static public int uniquename(String name) {
        Connection con;
        Statement st;
        ResultSet rs;
        List<String> l=new ArrayList<>();
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/MyStore?serverTimezone=UTC", "root", "");
            st = con.createStatement();
            rs = st.executeQuery("select * from users");
            while (rs.next()) {
                l.add(rs.getString(2));
            }
            //System.out.print(l);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        for(String i:l)
            if(name.equals(i))
                return 0;
        return 1;
    }
    private User addUserToDatabase(String name, String email,String age , String password) {
        User user = null;
        final String DB_URL = "jdbc:mysql://localhost/MyStore?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";

        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...

            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO users (name, email, age, password,gmoney) " +
                    "VALUES (?, ?, ?, ?,?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, age);
            preparedStatement.setString(4, password);
            preparedStatement.setString(5, "0");

            //Insert row into the table
            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                user = new User();
                user.name = name;
                user.email = email;
                user.age=age;
                user.password = password;
                user.money = "0";
            }

            stmt.close();
            conn.close();
        }catch(Exception e){
            e.printStackTrace();
        }

        return user;
    }
    private void connectToDatabase(String username) {

        //final String MYSQL_SERVER_URL = "jdbc:mysql://localhost/";
        final String DB_URL = "jdbc:mysql://localhost/myfriends?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";

        try{
            //First, connect to MYSQL server and create the database if not created
            //Second, connect to the database and create the table "users" if cot created
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = conn.createStatement();
            //String sql = "CREATE TABLE IF NOT EXISTS "+username+" ("
            //        + "friendname VARCHAR(200) NOT NULL,"
            //        + ")";
            String sql = "CREATE TABLE IF NOT EXISTS "+username+" ("
                    + "friendname VARCHAR(200) NOT NULL PRIMARY KEY,"
                    + "type VARCHAR(200) NOT NULL"
                    + ")";
            statement.executeUpdate(sql);


            statement.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }

    }
    private void connectToDatabase1(String username) {

        //final String MYSQL_SERVER_URL = "jdbc:mysql://localhost/";
        final String DB_URL = "jdbc:mysql://localhost/mygames?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";

        try{
            //First, connect to MYSQL server and create the database if not created
            //Second, connect to the database and create the table "users" if cot created
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement statement = conn.createStatement();
            //String sql = "CREATE TABLE IF NOT EXISTS "+username+" ("
            //        + "friendname VARCHAR(200) NOT NULL,"
            //        + ")";
            String sql = "CREATE TABLE IF NOT EXISTS "+username+" ("
                    + "gamename VARCHAR(200) NOT NULL PRIMARY KEY,"
                    + "type VARCHAR(200) NOT NULL"
                    + ")";
            statement.executeUpdate(sql);


            statement.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }

    }
    public static int verifyCode(int correctCode) {
        String enteredCode = JOptionPane.showInputDialog(null, "Please enter the code:");
        if (Integer.parseInt(enteredCode) == correctCode) {
            JOptionPane.showMessageDialog(null, "The code is correct.");
            return 1;
        } else {
            JOptionPane.showMessageDialog(null, "The code is incorrect.");
            return 0;
        }
    }
    public static void main(String[] args) {
        RegistrationForm myForm = new RegistrationForm(null);
        User user = myForm.user;
        if (user != null) {
            System.out.println("Successful registration of: " + user.name);
        }
        else {
            System.out.println("Registration canceled");
        }
    }
}
