public class User {
    public String name;
    public String email;
    public String age;
    public String password;
    public String money;

    public User(String name, String email, String age, String password, String money) {
        this.name = name;
        this.email = email;
        this.age = age;
        this.password = password;
        this.money = money;
    }
    public User()
    {}

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getAge() {
        return age;
    }

    public String getPassword() {
        return password;
    }

    public String getMoney() {
        return money;
    }
}
