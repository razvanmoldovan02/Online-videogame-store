import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class chat extends JFrame{
    private JPanel panel1;
    private JList list1;
    private JTextField msgText;
    private JButton sendButton;


    chat(User user, String friendname)
    {
        setMinimumSize(new Dimension(500, 300));
        setSize(600, 300);
        setContentPane(panel1);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        List<msg> l=new ArrayList<>();
        database(l, user.name,friendname);
        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                connectToDatabase(user.name,friendname, msgText.getText());
                //dispose();
                //new jlist(user,friendname);
                msgText.setText("");
                List<msg> l=new ArrayList<>();
                database(l, user.name,friendname);
                DefaultListModel<String> model = new DefaultListModel<>();
                for(msg i:l) {

                    model.addElement(i.getName()+": "+i.getMessage());
                }
                list1.setModel(model);
            }
        });
        DefaultListModel<String> model = new DefaultListModel<>();
        for(msg i:l) {
            model.addElement(i.getName()+": "+i.getMessage());
        }
        list1.setModel(model);

        // Add the JList to a scroll pane
        //frame.add(list1);

        }

    private void connectToDatabase(String username,String friendname,String message) {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            PreparedStatement ps = con.prepareStatement("insert into messages(fromUser,toUser,message) values(?,?,?)");
            ps.setString(1, username);
            ps.setString(2, friendname);
            ps.setString(3, message);
            ps.executeUpdate();
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "error");
        }
    }



    void database(List l, String uname, String friendname)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            Statement stmt = con.createStatement();
            //PreparedStatement ps = con.prepareStatement("select * from games");
            //InputStream is = new FileInputStream(new File(s));
            ResultSet rs;
            rs = stmt.executeQuery("select * from messages");
            while(rs.next()) {
                rs.getString(4);
                if(rs.getString(2).equals(uname) && rs.getString(3).equals(friendname))
                    l.add(new msg(rs.getString(2),rs.getString(4)));
                if(rs.getString(2).equals(friendname) && rs.getString(3).equals(uname))
                    l.add(new msg(rs.getString(2),rs.getString(4)));
            }

            stmt.close();
            con.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }

    }
   // public static void main(String[] args) {
       // new jlist("d","razvan");}
}

