import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Profile extends JFrame {
    private JButton btnCommunity;
    private JButton btnStore;
    private JButton btnProfile;
    private JButton btnFriends;
    private JButton btnGames;
    private JLabel lbName;
    private JButton friendRequestsButton;
    private JPanel N;
    private JPanel Profile;
    private JButton button1;

    public Profile(User user) {
        setContentPane(Profile);
        setVisible(true);

        setMinimumSize(new Dimension(150, 154));
        setMinimumSize(new Dimension(450, 474));
        setSize(800, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        btnCommunity.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Community(user);
            }
        });

        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(showConfirmPanel()==1)
                    dispose();
                new DashboardForm();
            }
        });
        friendRequestsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Friendrequest(user);
            }
        });
        btnProfile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Profile(user);
            }
        });
        btnStore.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Store(user);
            }
        });
        btnFriends.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Friends(user);
            }
        });
        btnGames.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Mygames(user);
            }
        });
    }
    public static int showConfirmPanel() {
        int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to log out?",
                "Confirmation Panel", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            return 1;
        } else {
            return 0;
        }
    }
}
