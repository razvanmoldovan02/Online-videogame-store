import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Basket extends JFrame{
    private JLabel lbImg;
    private JLabel lbGname;
    private JLabel lbDev;
    private JLabel lbPrice;
    private JLabel lbAge;
    private JButton buyButton;
    private JButton previousButton;
    private JButton nextButton;
    private JPanel Basket;
    private JLabel lbName;
    private JLabel Gmoney;
    private JPanel gamelabel;
    private JLabel nogameslb;
    private JButton removeButton;
    private JPanel nogmsL;
    private JButton buyGmoneyButton;
    int k=0;
    public Basket(User user)
    {
        setContentPane(Basket);
        setVisible(true);

        setMinimumSize(new Dimension(450, 474));
        setSize(500, 500);
        setLocationRelativeTo(null);
        java.util.List<Games> l=new ArrayList<>();
        database(l,user.name);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        nogmsL.setVisible(false);
        Gmoney.setText("Gmoney: "+user.money);
        show(l);

        if(k==0)
            previousButton.setEnabled(false);
        if(k==l.size()-1)
            nextButton.setEnabled(false);
        nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                k++;
                show(l);
                if(k>=l.size()-1)
                    nextButton.setEnabled(false);
                if(k!=0)
                    previousButton.setEnabled(true);

            }
        });
        buyGmoneyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
               new AddGmoney(user);
            }
        });
        previousButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                k--;
                show(l);
                if(k==0)
                    previousButton.setEnabled(false);
                if(k!=l.size()-1)
                    nextButton.setEnabled(true);
            }
        });
        buyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(Integer.parseInt(user.money)>=Integer.parseInt(l.get(k).price) )
                {if( showConfirmPanel()== 1)
                {buygame(user.name,l.get(k).name);
                //database(l,user.name);
                 user.money=Integer.toString(Integer.parseInt(user.money)-Integer.parseInt(l.get(k).price));
                l.remove(k);

                updategmoney(user);
                if(k!=0)
                    k--;
                if(k==0)
                    previousButton.setEnabled(false);
                if(k>=l.size()-1)
                    nextButton.setEnabled(false);
                show(l);
                dispose();
                    new Basket(user);
                }}
                else
                {JOptionPane.showMessageDialog(null, "Not enough gmoney", "Error", JOptionPane.ERROR_MESSAGE);
                }

            }
        });
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                removegame(user.name,l.get(k).name);
                //database(l,user.name);
                l.remove(k);

                if(k!=0)
                k--;
                if(k==0)
                    previousButton.setEnabled(false);
                if(k>=l.size()-1)
                    nextButton.setEnabled(false);
                show(l);
            }
        });
    }
    public static int showConfirmPanel() {
        int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to make this purchase?",
                "Confirmation Panel", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            return 1;
        } else {
            return 0;
        }
    }
    void show(java.util.List<Games> l)
    {   if(l.isEmpty()) {
        nogmsL.setVisible(true);
        nogameslb.setText("The basket is empty");
        gamelabel.setVisible(false);
        previousButton.setEnabled(false);
        nextButton.setEnabled(false);
    }
    /*if(l.size()==1)
    {
        previousButton.setEnabled(false);
        nextButton.setEnabled(false);
    }*/
        else {
        lbGname.setText("Name: " + l.get(k).name);
        lbDev.setText("Developer: " + l.get(k).dev);
        lbAge.setText("Minimum age: " + l.get(k).age);
        lbPrice.setText("Price: " + l.get(k).price+" gmoney");
        try {
            int myblobLength = (int) l.get(k).Image.length();
            byte[] my = l.get(k).Image.getBytes(1, myblobLength);
            ImageIcon gg = new ImageIcon(my);
            lbImg.setIcon(gg);
        } catch (Exception ee) {
        }
    }
    }
    private void updategmoney(User user) {
        final String DB_URL = "jdbc:mysql://localhost/mystore?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...
            Statement stmt = conn.createStatement();
            String sql = "update users set gmoney = ? where name = ?";
            PreparedStatement preparedStatement1 = conn.prepareStatement(sql);
            preparedStatement1.setInt(1, Integer.parseInt(user.money));
            preparedStatement1.setString(2, user.name);
            preparedStatement1.executeUpdate();


            stmt.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
    void database(List<Games> l,String uname)
    {   Games g = new Games();
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            Statement stmt = con.createStatement();
            //PreparedStatement ps = con.prepareStatement("select * from games");
            //InputStream is = new FileInputStream(new File(s));
            ResultSet rs;
            rs = stmt.executeQuery("select * from games");
            ResultSet rs1;
            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/mygames?serverTimezone=UTC","root","");
            Statement stmt1 = con1.createStatement();
            while(rs.next()) {
                g.name = rs.getString(1);
                g.dev = rs.getString(2);
                g.price = rs.getString(4);
                g.age = rs.getString(3);
                g.Image = rs.getBlob(5);
                g.rating = rs.getFloat(6);
                rs1 = stmt1.executeQuery("select * from "+uname);
                while(rs1.next())
                    if (rs1.getString(1).equals(g.name))
                        if (rs1.getString(2).equals("basket"))
                            l.add(new Games(g.name, g.dev, g.age, g.price, g.Image,g.rating));
            }

             stmt.close();
             con.close();
            stmt1.close();
            con1.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }

    }
    private void buygame(String uname,String game) {
        final String DB_URL = "jdbc:mysql://localhost/mygames?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        int ok=0;
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...
            Statement stmt = conn.createStatement();
            String sql = "update "+uname+" set type = ? where gamename = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, "bought");
            preparedStatement.setString(2, game);
            preparedStatement.executeUpdate();


            stmt.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
    private void removegame(String uname,String game) {
        final String DB_URL = "jdbc:mysql://localhost/mygames?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        int ok=0;
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...
            Statement stmt = conn.createStatement();
            String sql = "delete from "+uname+" where gamename = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, game);
            preparedStatement.executeUpdate();


            stmt.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        User user =new User();
        new Basket(user);
    } }

