import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Reviews extends JFrame{
    private JPanel Review;
    private JList list1;
    private JButton AddReview;
    private JButton DeleteButton;
    private JTextField msgText;



    public Reviews(User user, Games game)
    {
        setMinimumSize(new Dimension(500, 300));
        setSize(600, 500);
        setContentPane(Review);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        List<Review> l=new ArrayList<>();
        Review rev=new Review();
        rev.rating=0;
        rev=database(l,game.name,rev,user);
        Review finalRev = rev;
        avgrating(l,game.name);
        if(rev.name==null)
            DeleteButton.setEnabled(false);
        DeleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DeleteReview(user.name,game.name);
                dispose();
                new Reviews(user,game);
            }
        });
        AddReview.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();

                new ReviewForm(user,game, finalRev);
            }
        });
        DefaultListModel<String> model = new DefaultListModel<>();
        for(Review i:l) {
            model.addElement("__________________________________________________");
            String stars="";
            for(int j=0;j<i.getRating();j++)
                stars=stars+"★";
            for(int j=i.getRating();j<5;j++)
                stars=stars+"☆";
            model.addElement("Username: "+i.getName());
            model.addElement("Rating: "+stars);
            model.addElement("");
            String review=i.getText();
            while(review.length()>45)
            {   int k;
                for(k=44;k>0;k--)
                if(review.substring(0,45).toCharArray()[k]==' ')
                break;
                if(k==0)
                    k=45;
                model.addElement(review.substring(0,k+1));
                review=review.substring(k+1);}
            model.addElement(review);
            model.addElement("‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾");

        }
        list1.setModel(model);

        // Add the JList to a scroll pane
        //frame.add(list1);

    }
    Review database(List l, String gname,Review rev,User user)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            Statement stmt = con.createStatement();
            //PreparedStatement ps = con.prepareStatement("select * from games");
            //InputStream is = new FileInputStream(new File(s));
            ResultSet rs;
            rs = stmt.executeQuery("select * from reviews");
            while(rs.next()) {
                if(rs.getString(3).equals(gname))
                { l.add(new Review(rs.getString(4),rs.getInt(5),rs.getString(2)));
                    if(rs.getString(4).equals(user.name))
                        rev=new Review(user.name,rs.getInt(5),rs.getString(2));}

            }

            stmt.close();
            con.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
return rev;
    }
    private void DeleteReview(String username,String game) {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            Statement statement = con.createStatement();
             statement.executeUpdate("DELETE FROM reviews WHERE user = '" + username + "' AND game = '" + game + "'");
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "error");
        }
    }
    private void avgrating(List<Review> l,String gname) {
        float rating =0;
        for(Review i:l)
            rating=rating+i.rating;
        if(rating!=0)
            rating=rating/l.size();
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            Statement statement = con.createStatement();
            statement.executeUpdate("UPDATE games SET rating = "+rating+" WHERE name = '"+ gname + "'");
        }catch(Exception ex){
            System.out.print("");
        }
    }
    // public static void main(String[] args) {
    // new jlist("d","razvan");}
}
