import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;

public class ReviewForm extends JFrame {
    private int rating;
    public ReviewForm(User user,Games game,Review rev) {
        // Set the frame properties
        setVisible(true);
        setTitle("Write a Review");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Create a panel to hold the review form
        JPanel reviewPanel = new JPanel();
        reviewPanel.setLayout(new BoxLayout(reviewPanel, BoxLayout.Y_AXIS));
        reviewPanel.setBackground(new Color(183,217,215));

        // Create the review text area
        JTextArea reviewTextArea = new JTextArea();
        reviewTextArea.setLineWrap(true);
        reviewTextArea.setWrapStyleWord(true);
        reviewTextArea.setPreferredSize(new Dimension(350, 150));
        reviewTextArea.setMaximumSize(new Dimension(350, 150));
        reviewTextArea.setBorder(new TitledBorder("Write your review here:"));
        reviewTextArea.setFont(new Font("Arial", Font.PLAIN, 14));
        if(rev.rating!=0)
            rating=rev.rating;
        reviewTextArea.setText(rev.text);
        reviewPanel.add(reviewTextArea);
        // Create the star rating panel
        JPanel ratingPanel = new JPanel();
        ratingPanel.setLayout(new BoxLayout(ratingPanel, BoxLayout.X_AXIS));
        ratingPanel.setBackground(new Color(163,198,196));
        ratingPanel.setBorder(new TitledBorder("Select a star rating:"));
        // Create the star rating buttons
        ButtonGroup ratingGroup = new ButtonGroup();
        for (int i = 1; i <= 5; i++) {
            JRadioButton ratingButton = new JRadioButton(Integer.toString(i));
            ratingButton.setFont(new Font("Arial", Font.PLAIN, 14));
            ratingGroup.add(ratingButton);
            ratingPanel.add(ratingButton);
            int finalI = i;
            ratingButton.setContentAreaFilled(true);
            ratingButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    rating = finalI;
                }
            });
        }


        // Add the rating panel to the review panel
        reviewPanel.add(ratingPanel);

        // Create the submit button
        JButton submitButton = new JButton("Submit");
        submitButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        submitButton.setBackground(new Color(163,198,196));
        submitButton.setForeground(Color.BLACK);
        submitButton.setFont(new Font("Arial", Font.BOLD, 16));
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the review and rating from the review panel
                String review = reviewTextArea.getText();
                int rating = ReviewForm.this.rating;
                DeleteReview(user.name,game.name);
                AddReview(user.name,game.name,review,rating);
                dispose();
                new Reviews(user,game);
            }
        });
        reviewPanel.add(submitButton);

        // Add the review panel to the frame
        add(reviewPanel);

    }
    private void DeleteReview(String username,String game) {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            Statement statement = con.createStatement();
            int rowsAffected = statement.executeUpdate(
                    "DELETE FROM reviews WHERE user = '" + username + "' AND game = '" + game + "'");
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "error");
        }
    }
    private void AddReview(String username,String game,String review,int rating) {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            /*
            Statement statement = con.createStatement();
            ResultSet resultSet = statement.executeQuery(
                    "SELECT COUNT(*) FROM reviews WHERE user = '" + username + "' AND game = '" + game + "'");
            if (resultSet.next() && resultSet.getInt(1) > 0) {
                JOptionPane.showMessageDialog(null, username + " has already written a review for " + game);
            } else {*/
            PreparedStatement ps = con.prepareStatement("insert into reviews(review,game,user,rating) values(?,?,?,?)");
            ps.setString(1, review);
            ps.setString(2, game);
            ps.setString(3, username);
            ps.setInt(4, rating);
            ps.executeUpdate();
            con.close();
            //statement.close();
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "error");
        }
    }
}