import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class Addgame1 extends JFrame{
    JButton button;
    JButton button2;
    JLabel label;
    JTextField textPRICE;
    JTextField [] g;
    JTextField textAGE;
    JTextField textDEV;
    JTextField textNAME;
    JTextArea area;
    String s;

    public Addgame1(){
        super("Insert a game to database in Java");
        setLocationRelativeTo(null);
        setBackground(Color.LIGHT_GRAY);
        setLayout(null);

        // Set background and foreground colors for button
        button = new JButton("ADD");
        button.setBackground(Color.GREEN);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBounds(200,300,100,40);

        button2 = new JButton("Browse");
        button2.setBackground(Color.BLUE);
        button2.setForeground(Color.WHITE);
        button2.setFont(new Font("Arial", Font.BOLD, 14));
        button2.setBounds(80, 300, 100, 40);

        // Set background and foreground colors for text fields
        textPRICE = new JTextField("Price");
        textPRICE.setBackground(Color.WHITE);
        textPRICE.setForeground(Color.BLACK);
        textPRICE.setFont(new Font("Arial", Font.PLAIN, 14));
        textPRICE.setBounds(490,295,100,20);

        textDEV = new JTextField("Developer");
        textDEV.setBackground(Color.WHITE);
        textDEV.setForeground(Color.BLACK);
        textDEV.setFont(new Font("Arial", Font.PLAIN, 14));
        textDEV.setBounds(350,325,100,20);

        textAGE = new JTextField("Age");
        textAGE.setBackground(Color.WHITE);
        textAGE.setForeground(Color.BLACK);
        textAGE.setFont(new Font("Arial", Font.PLAIN, 14));
        textAGE.setBounds(490,325,100,20);

        textNAME = new JTextField("Name");
        textNAME.setBackground(Color.WHITE);
        textNAME.setForeground(Color.BLACK);
        textNAME.setFont(new Font("Arial", Font.PLAIN, 14));
        textNAME.setBounds(350,295,100,20);
        label = new JLabel();
        label.setBounds(200,10,250,250);
        label.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        label.setOpaque(true);

        //button to browse the image into jlabel
        button2.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                FileNameExtensionFilter filter = new FileNameExtensionFilter("*.IMAGE", "jpg","gif","png");
                fileChooser.addChoosableFileFilter(filter);
                int result = fileChooser.showSaveDialog(null);
                if(result == JFileChooser.APPROVE_OPTION){
                    File selectedFile = fileChooser.getSelectedFile();
                    String path = selectedFile.getAbsolutePath();
                    label.setIcon(ResizeImage(path));
                    s = path;
                }
                else if(result == JFileChooser.CANCEL_OPTION){
                    System.out.println("No Data");
                }
            }
        });

        //button to insert image and some data into mysql database
        button.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                try{
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
                    PreparedStatement ps = con.prepareStatement("insert into games(name,developer,age,price,image) values(?,?,?,?,?)");
                    InputStream is = new FileInputStream(new File(s));

                    ps.setString(1, textNAME.getText());
                    ps.setString(2, textDEV.getText());
                    ps.setString(3, textAGE.getText());
                    ps.setString(4, textPRICE.getText());
                    ps.setBlob(5,is);
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Data Inserted");
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(null, "This game already exist");
                }
            }
        });

        add(label);
        add(textPRICE);
        add(textDEV);
        add(textAGE);
        add(textNAME);
        add(button);
        add(button2);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700,400);
        setVisible(true);
    }

    //method to resize the image
    public ImageIcon ResizeImage(String ImagePath){
        ImageIcon MyImage = new ImageIcon(ImagePath);
        Image img = MyImage.getImage();
        Image newImg = img.getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }
    public static void main(String[] args){
        new Addgame1();
    }
}