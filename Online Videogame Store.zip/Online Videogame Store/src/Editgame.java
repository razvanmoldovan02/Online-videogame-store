import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Editgame extends JFrame{
    private JPanel Editgame;
    private JLabel lbGname;
    private JLabel lbDev;
    private JLabel lbPrice;
    private JButton addButton;
    private JLabel lbImg;
    private JTextField textDEV;
    private JTextField textPRICE;
    private JTextField textAGE;
    private JButton ChangeBtn;
    private JTextField textNAME;
    String s;
    Blob imgg;

    Editgame(Games game)
    {
        s=null;
        if(game.name!=null)
    {
        ChangeBtn.setText("Change photo");
        addButton.setText("Update");
        imgg=game.Image;
        try {
            int myblobLength = (int) imgg.length();
            byte[] my = game.Image.getBytes(1, myblobLength);
            ImageIcon gg = new ImageIcon(my);
            lbImg.setIcon(gg);
        }
        catch(Exception ee){}

        textNAME.setText(game.name);
        textNAME.setEditable(false);
        textDEV.setText(game.dev);
        textPRICE.setText(game.price);
        textAGE.setText(game.age);

    }

        setVisible(true);
        setTitle("Community");
        setContentPane(Editgame);
        setMinimumSize(new Dimension(600, 300));
        setSize(600, 300);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        ChangeBtn.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                FileNameExtensionFilter filter = new FileNameExtensionFilter("*.IMAGE", "jpg","gif","png");
                fileChooser.addChoosableFileFilter(filter);
                int result = fileChooser.showSaveDialog(null);
                if(result == JFileChooser.APPROVE_OPTION){
                    File selectedFile = fileChooser.getSelectedFile();
                    String path = selectedFile.getAbsolutePath();
                    lbImg.setIcon(ResizeImage(path));
                    s = path;
                }
                else if(result == JFileChooser.CANCEL_OPTION){
                    System.out.println("No Data");
                }
            }
        });
        addButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                if(game.name!=null)
                deletegame(game.name);
                addgame(textNAME.getText(),textDEV.getText(),textAGE.getText(),textPRICE.getText());
        }});

    }
    public ImageIcon ResizeImage(String imgPath){
        ImageIcon MyImage = new ImageIcon(imgPath);
        Image img = MyImage.getImage();
        Image newImage = img.getScaledInstance(lbImg.getWidth(), lbImg.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImage);
        return image;
    }

    public void deletegame(String gname) {
        Connection conn = null;
        PreparedStatement stmt = null;
        String deleteSql = "DELETE FROM games WHERE name = ?";
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/mystore", "root", "");
            stmt = conn.prepareStatement(deleteSql);
            stmt.setString(1, gname); // set the value for the "?" placeholder
            int rowsDeleted = stmt.executeUpdate();
            //System.out.println(rowsDeleted + " rows deleted");
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

    }

    public void addgame(String name,String dev,String age,String price)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            PreparedStatement ps = con.prepareStatement("insert into games(name,developer,age,price,image,rating) values(?,?,?,?,?,?)");
            InputStream is;
            if(s!=null)
            is = new FileInputStream(new File(s));
            else
            is=imgg.getBinaryStream();
            ps.setString(1, name);
            ps.setString(2, dev);
            ps.setString(3, age);
            ps.setString(4, price);
            ps.setBlob(5,is);
            ps.setFloat(6,0);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Inserted");
        }catch(Exception ex){
            //System.out.println(ex);
            JOptionPane.showMessageDialog(null, "This game already exist");
        }
    }

}
