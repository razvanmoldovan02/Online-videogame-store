import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Calendar;

public class AddGmoney extends JFrame{
    private JPanel AddGmoney;
    private JLabel lbName;
    private JTextField DateText;
    private JButton btnOK;
    private JButton btnCancel;
    private JTextField CardText;
    private JTextField CvvText;
    private JSpinner spinner1;

    AddGmoney(User user)
    {
        setTitle("Buy");
        setContentPane(AddGmoney);
        setMinimumSize(new Dimension(450, 474));

        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        //spinner1.setValue(50);
        btnCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        btnOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //System.out.println("Invalid card number");
                int ok=0;
                int value = (Integer)spinner1.getValue();
                String cardNumber = CardText.getText();
                String expirationDate = DateText.getText();
                String securityCode = CvvText.getText();
                if (!isValidCardNumber(cardNumber)) {
                    JOptionPane.showMessageDialog(null,
                            "Invalid card number", "Error", JOptionPane.ERROR_MESSAGE);
                    ok=1;
                }
                if (!isValidExpirationDate(expirationDate)) {
                    JOptionPane.showMessageDialog(null,
                            "Invalid expiration date", "Error", JOptionPane.ERROR_MESSAGE);
                    ok=1;
                }
                if (!isValidSecurityCode(securityCode)) {
                    JOptionPane.showMessageDialog(null,
                            "Invalid security code", "Error", JOptionPane.ERROR_MESSAGE);
                    ok=1;
                }
                if(ok==0)
                    if (showConfirmPanel()== 1) {
                    buygmoney(user,value);
                    dispose();
                    new Basket(user);
                    }
            }
        });
        setVisible(true);
    }
    public static int showConfirmPanel() {
        int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to make this purchase?",
                "Confirmation Panel", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            return 1;
        } else {
            return 0;
        }
    }
    private static boolean isValidCardNumber(String cardNumber) {
        // Remove any spaces or dashes from the card number
        cardNumber = cardNumber.replaceAll("[ -]", "");

        // Check that the card number is the correct length
        if (cardNumber.length() < 12 || cardNumber.length() > 19) {
            return false;
        }

        // Check that the card number is all digits
        if (!cardNumber.matches("\\d+")) {
            return false;
        }

        // Check the card number using the Luhn algorithm
        int sum = 0;
        boolean isEven = false;
        for (int i = cardNumber.length() - 1; i >= 0; i--) {
            int digit = Integer.parseInt(cardNumber.substring(i, i + 1));
            if (isEven) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }
            sum += digit;
            isEven = !isEven;
        }
        return sum % 10 == 0;
    }
    private static boolean isValidExpirationDate(String expirationDate) {
        // Check that the expiration date is in the correct format (MM/YYYY)
        if (!expirationDate.matches("\\d{2}/\\d{4}")) {
            return false;
        }

        // Parse the month and year from the expiration date
        int month = Integer.parseInt(expirationDate.substring(0, 2));
        int year = Integer.parseInt(expirationDate.substring(3));

        // Check that the month is between 1 and 12
        if (month < 1 || month > 12) {
            return false;
        }

        // Check that the year is in the future
        Calendar calendar = Calendar.getInstance();
        int currentYear = calendar.get(Calendar.YEAR);
        int currentMonth = calendar.get(Calendar.MONTH) + 1; // January is 0
        if (year < currentYear || (year == currentYear && month < currentMonth)) {
            return false;
        }

        return true;
    }
    private static boolean isValidSecurityCode(String securityCode) {
        // Check that the security code is the correct length
        if (securityCode.length() != 3 && securityCode.length() != 4) {
            return false;
        }

        // Check that the security code is all digits
        if (!securityCode.matches("\\d+")) {
            return false;
        }

        return true;
    }
    private void buygmoney(User user,int gmoney) {
        final String DB_URL = "jdbc:mysql://localhost/mystore?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...
            Statement stmt = conn.createStatement();
            String sql = "update users set gmoney = ? where name = ?";
            PreparedStatement preparedStatement1 = conn.prepareStatement(sql);
            preparedStatement1.setInt(1, Integer.parseInt(user.money)+gmoney);
            preparedStatement1.setString(2, user.name);
            preparedStatement1.executeUpdate();
            user.money=Integer.toString(Integer.parseInt(user.money)+gmoney);

            stmt.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

