import javax.swing.*;
import java.sql.Blob;

public class Games {
    public String name;
    public String dev;

    public String age;
    public String price;
    public Blob Image;
    public float rating;

    public Games(String name, String dev, String age, String price, Blob Image,float rating) {
        this.name = name;
        this.dev = dev;
        this.age = age;
        this.price = price;
        this.Image = Image;
        this.rating=rating;
    }
    public Games()
    {}

    @Override
    public String toString() {
        return "Games{" +
                "name='" + name + '\'' +
                ", dev='" + dev + '\'' +
                ", age='" + age + '\'' +
                ", price='" + price + '\'' +
                ", Image=" + Image +
                '}';
    }
}
