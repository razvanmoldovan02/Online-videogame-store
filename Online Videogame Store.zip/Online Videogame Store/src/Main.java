public class Main {
    public static void main(String[] args) {
        DashboardForm myForm = new DashboardForm();
    }
}