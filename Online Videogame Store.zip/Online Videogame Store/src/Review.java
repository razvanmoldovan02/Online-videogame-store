public class Review {
    String name;
    int rating;
    String text;

    public Review(String name, int rating, String text) {
        this.name = name;
        this.rating = rating;
        this.text = text;
    }
    public Review()
    {}

    public String getName() {
        return name;
    }

    public int getRating() {
        return rating;
    }

    public String getText() {
        return text;
    }
}
