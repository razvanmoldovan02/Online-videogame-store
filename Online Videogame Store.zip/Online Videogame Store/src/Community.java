
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Community extends JFrame{
    private JPanel communityPanel;
    private JButton btnCommunity;
    private JButton btnStore;
    private JButton btnProfile;
    private JLabel lbName;
    private JTextField tfFriends;
    private JButton btAdd;
    private JLabel lbFriends;
    private JButton btnSearch;
    private JLabel label1;

    public Community(User user) {
        //super(parent);
        btAdd.setVisible(false);
        setVisible(true);
        setTitle("Community");
        setContentPane(communityPanel);
        setMinimumSize(new Dimension(450, 474));
        setSize(800, 800);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        if(user.name.equals("admin"))
        {btnProfile.setVisible(false);
            label1.setText("Search for a user");
            btAdd.setText("Delete");}
        btnCommunity.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();new Community(user);

            }
        });
        btnProfile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); new Profile(user);
            }
        });
        btnStore.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); new Store(user);
            }
        });
        btnSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fname = tfFriends.getText();
                int ok = searchfriends(fname, user.name);
                if(fname.equals("admin"))
                    ok=2;
                if (ok == 0)
                { lbFriends.setText("user not found");
                    btAdd.setVisible(false);}
                else if (ok == 1) {
                    lbFriends.setText("user found");
                    btAdd.setVisible(true);
                } else if (ok == 2)
                {lbFriends.setText("You can't add this user as a friend");
                btAdd.setVisible(false);}
            }
        });
        btAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String fname = tfFriends.getText();
                if(user.name.equals("admin"))
                {if(showConfirmPanel()==1)
                    deleteUser(fname);
                    btAdd.setVisible(false);
                }
                else
                { addfriends(fname,user.name);
                    btAdd.setVisible(false);}
            }
        });

    }

    public void deleteUser(String uname) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            stmt = conn.prepareStatement("DELETE FROM users WHERE name = ?");
            stmt.setString(1, uname);
            stmt.executeUpdate();
            stmt.close();
            conn.close();
            List<String> l=new ArrayList<>();
            database(l,uname);
            conn = DriverManager.getConnection("jdbc:mysql://localhost/myfriends","root","");
            for(String i:l)
            {stmt = conn.prepareStatement("DELETE FROM "+i+" WHERE friendname = ?");
                stmt.setString(1, uname);
                stmt.executeUpdate();}
            stmt.close();
            conn.close();
            conn = DriverManager.getConnection("jdbc:mysql://localhost/myfriends","root","");
            stmt = conn.prepareStatement("drop table "+uname);
            stmt.executeUpdate();
            stmt.close();
            conn.close();
            conn = DriverManager.getConnection("jdbc:mysql://localhost/mygames","root","");
            stmt = conn.prepareStatement("drop table "+uname);
            stmt.executeUpdate();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            // handle the exception
        }}
    void database(List<String> l, String uname)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/myfriends","root","");
            Statement stmt = con.createStatement();
            //PreparedStatement ps = con.prepareStatement("select * from games");
            //InputStream is = new FileInputStream(new File(s));
            ResultSet rs;
            rs = stmt.executeQuery("select * from "+uname);
            while(rs.next()) {
                if(rs.getString(2).equals("friends"))
                    l.add( new String(rs.getString(1)));

            }
            stmt.close();
            con.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }

    }
    public static int showConfirmPanel() {
        int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to remove this user?",
                "Confirmation Panel", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            return 1;
        } else {
            return 0;
        }
    }
    private int searchfriends(String fname,String uname) {
        if(fname.equals(uname))
            return 2;
        final String DB_URL = "jdbc:mysql://localhost/myfriends?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        int ok=0;
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...

            Statement stmt = conn.createStatement();
            try {
                ResultSet rs;
                rs = stmt.executeQuery( "SELECT * FROM "+fname);}
            catch(Exception e){
                return ok;
            }
                ok=1;
                ResultSet rs;
                rs = stmt.executeQuery("select * from "+uname+" where friendname='"+fname+"'");
                rs.next();
                try {
                rs.getString(1);
                    ok=2;}
                catch(Exception e){
                    return ok;
                }

            stmt.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }
        return ok;
    }
        private void addfriends(String fname,String uname) {
            final String DB_URL = "jdbc:mysql://localhost/myfriends?serverTimezone=UTC";
            final String USERNAME = "root";
            final String PASSWORD = "";
            int ok=0;
            try{
                Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                // Connected to database successfully...
                Statement stmt = conn.createStatement();
                String sql = "INSERT INTO "+uname+" (friendname,type) " +
                        "VALUES (?,?)";
                PreparedStatement preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, fname);
                preparedStatement.setString(2, "receive request");
                preparedStatement.executeUpdate();

               sql = "INSERT INTO "+fname+" (friendname,type) " +
                        "VALUES (?,?)";
                 preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, uname);
                preparedStatement.setString(2, "send request");
                preparedStatement.executeUpdate();

                stmt.close();
                conn.close();

            }catch(Exception e){
                e.printStackTrace();
            }
        }

}
