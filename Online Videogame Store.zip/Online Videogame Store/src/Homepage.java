import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Homepage extends JFrame {
    private JPanel homepagePanel;
    private JButton btnCommunity;
    private JButton btnStore;
    private JButton btnProfile;
    private JLabel lbName;
    private JLabel lbWelcome;


    public Homepage(User user) {
        User user1=user;
        //super(parent);
        setTitle("Homepage");
        setVisible(true);
        setContentPane(homepagePanel);
        setMinimumSize(new Dimension(450, 474));
        setSize(800, 800);
        //setModal(true);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        if(user.name.equals("admin"))
            btnProfile.setVisible(false);
        //Community v = new Community(user);
        btnCommunity.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();new Community(user);
            }
        });
        btnProfile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); new Profile(user);
            }
        });
        btnStore.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); new Store(user);
            }
        });
       if (user != null) {
            lbWelcome.setText("Welcome " + user.name);

        }
       JButton a=new JButton();
    }
    public static void main(String[] args) {
        User user =new User();
        Homepage h = new Homepage(user);

    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}