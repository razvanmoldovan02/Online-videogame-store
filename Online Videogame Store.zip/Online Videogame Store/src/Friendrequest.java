
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Friendrequest extends JDialog {
    private JPanel Friendrequest;
    private JPanel friendlabel;
    private JButton acceptButton;
    private JButton removeButton;
    private JButton previousButton;
    private JButton nextButton;
    private JLabel FriendsR;
    private JLabel lbName;
    int k = 0;


    public Friendrequest(User user)
    {
        setContentPane(Friendrequest);
        setVisible(true);

        setMinimumSize(new Dimension(450, 474));
        setSize(500, 500);
        setModal(true);
        setLocationRelativeTo(null);
        java.util.List<String> l=new ArrayList<>();
        database(l,user.name);
        show(l);

        if(k==0)
            previousButton.setEnabled(false);
        if(k==l.size()-1)
            nextButton.setEnabled(false);
        nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                k++;
                show(l);
                if(k>=l.size()-1)
                    nextButton.setEnabled(false);
                if(k!=0)
                    previousButton.setEnabled(true);

            }
        });
        previousButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                k--;
                show(l);
                if(k==0)
                    previousButton.setEnabled(false);
                if(k!=l.size()-1)
                    nextButton.setEnabled(true);
            }
        });
        acceptButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                accept(user.name,l.get(k));
                //database(l,user.name);
                l.remove(k);

                if(k!=0)
                    k--;
                if(k==0)
                    previousButton.setEnabled(false);
                if(k>=l.size()-1)
                    nextButton.setEnabled(false);
                show(l);
            }
        });
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                remove(user.name,l.get(k));
                //database(l,user.name);
                l.remove(k);

                if(k!=0)
                    k--;
                if(k==0)
                    previousButton.setEnabled(false);
                if(k>=l.size()-1)
                    nextButton.setEnabled(false);
                show(l);
            }
        });
    }
    void show(List l)
    {   if(l.isEmpty()) {
        FriendsR.setVisible(true);
        acceptButton.setEnabled(false);
        removeButton.setEnabled(false);
        FriendsR.setText("No friend requests");
        //friendlabel.setVisible(false);
        previousButton.setEnabled(false);
        nextButton.setEnabled(false);

        if (l.size() == 1) {
            previousButton.setEnabled(false);
            nextButton.setEnabled(false);
        }
    }
    else
        FriendsR.setText("Name: " + l.get(k));
    }
    void database(List<String> l, String uname)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/myfriends","root","");
            Statement stmt = con.createStatement();
            //PreparedStatement ps = con.prepareStatement("select * from games");
            //InputStream is = new FileInputStream(new File(s));
            ResultSet rs;
            rs = stmt.executeQuery("select * from "+uname);
            while(rs.next()) {
                //System.out.println(rs.getString(1));
                 if(rs.getString(2).equals("send request"))
                    l.add( new String(rs.getString(1)));

            }
            //System.out.println(l);
            stmt.close();
            con.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }

    }
    private void accept(String uname,String fname) {
        final String DB_URL = "jdbc:mysql://localhost/myfriends?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        int ok=0;
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...
            Statement stmt = conn.createStatement();
            String sql = "update "+uname+" set type = ? where friendname = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, "friends");
            preparedStatement.setString(2, fname);
            preparedStatement.executeUpdate();

            sql = "update "+fname+" set type = ? where friendname = ?";
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, "friends");
            preparedStatement.setString(2, uname);
            preparedStatement.executeUpdate();


            stmt.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
    private void remove(String uname,String fname) {
        final String DB_URL = "jdbc:mysql://localhost/myfriends?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        int ok=0;
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...
            Statement stmt = conn.createStatement();
            String sql = "delete from "+uname+" where friendname = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, fname);
            preparedStatement.executeUpdate();
             sql = "delete from "+fname+" where friendname = ?";
             preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, uname);
            preparedStatement.executeUpdate();

            stmt.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        User user =new User();
        new Friendrequest(user);
    } }


